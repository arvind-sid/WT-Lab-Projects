<?php
$connect=mysqli_connect("localhost","root","","form");
$fn=$_POST["First_Name"];
$ln=$_POST["Last_Name"];
$db=$_POST["Date_of_Birth"];
$p=$_POST["Mobile_Number"];
$e=$_POST["Email_Id"];
$query="INSERT INTO form(First_Name,Last_Name,Date_of_Birth,Mobile_Number,Email_Id) VALUES ('$fn','$ln','$db','$p','$e')";
$res=mysqli_query($connect,$query);
if($res){
        echo "<script>alert('registered Successfully...')</script>";
}
else{
        echo "<script>alert('registration Falied...')</script>";
}
?>
<body bgcolor="lavender">
<center><h1 style="color:blue">Your Details</h1></center>
<table align="center" cellspacing="0" cellpadding="5" bgcolor="lightblue"  border="1">
      <tr><td>User:</td>
          <td><?php echo $fn ?></td>
          <tr><td>User:</td>
          <td><?php echo $ln ?></td>
          <tr><td>DOB:</td>
          <td><?php echo $db ?></td>
          <tr><td>Mobile Number:</td>
          <td><?php echo $p ?></td>
          <tr><td>Email:</td>
          <td><?php echo $e ?></td>
  
        <tr><td colspan="2"><button>Previous</button><button>Submit</button><button>Reset</button><button>Next</button></td></tr>
</table>
</body>